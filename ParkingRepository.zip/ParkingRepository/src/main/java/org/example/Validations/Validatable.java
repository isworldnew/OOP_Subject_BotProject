package org.example.Validations;

import org.example.db.LocalDataBaseInteraction;

public interface Validatable {
    public boolean isValid(String text);

}
